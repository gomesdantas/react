import { useState } from 'react';
import Cabecalho from '../../components/cabecalho/';
import Adicionar from '../../components/adicionarproduto';

export default function Sorveteria(props) {


    const [produto, setProduto] = useState('');
    const [valorrr, setValorrr] = useState(0);
    const [sorvetes, setSorvetes] = useState([]);



    return (


        <div className="pagina-svt">

            <Cabecalho />
            <div className="container">

                <div className="sorvetinho">

                    <h1>Sorveteria</h1>

                    <img src='/assets/images/sorvetes.png' />
                </div>

                <div className="quadro">

                    <div className="novoItem">

                        <div>
                            <p> Novo Item </p>
                            <input type='text' value={produto} onChange={e => setProduto(e.target.value)} />
                        </div>
                        <div>
                            <p> R$ </p> <input type='text' value={valorrr} onChange={e => setValorrr(Number(e.target.value))} />
                        </div>

                        <button onClick={Adicionar}> Adicionar </button>

                    </div>

                    <div className='tabela'>
                        <p> Lista de Compras {props.arraia}</p>

                        <div>

                            <p > Total: </p>



                        </div>

                        <div className='produtos'>                       
                            {
                                sorvetes.map(item => <itemDaLista produtos={item.produtos} valorrr={item.valorrr}/>)
                            }
                        </div>

                    </div>

                </div>


            </div>
        </div>

    )

}