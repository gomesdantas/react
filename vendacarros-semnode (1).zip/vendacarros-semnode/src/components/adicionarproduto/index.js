import { useState } from "react";


export default function Adicionar(props) {

    let soma = 0;

    const [arraia, setArraia] = useState([]);

    let lista = {


        produto: props.produto,
        valorrr: props.valorrr

    }


    setArraia([lista, arraia])
    setArraia('')


soma = soma + props.valorrr;

    return (

        <div>
            {arraia.map(

                item => <div className='pedidos'> {item} </div>

            )}
        </div>

    )

} 