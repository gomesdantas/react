import './index.scss';

export default function Cabecalho () {
        return (

        <div className="cabecalho"> 
            <img className="logo" src="/assets/images/logo.png"></img>

        </div>  
        )

}