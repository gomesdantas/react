export default function itemDaLista(props) {
    return(
        <div>
            <h4>{props.produto}</h4>
            <h4>{props.valorrr}</h4>
        </div>
    )
}