import { useState } from "react";
import Cabecalho from '../../components/cabecalho';
import './index.scss'




export default function Sorveteria() {

    const [sorvete, setSorvete] = useState('');
    const [preco, setPreco] = useState(0);
    const [resultado, setResultado] = useState(0);
    const [lista, setLista] = useState([]);

    const Mostrar = () => {
        let x = preco + resultado;
        setResultado(x)
        let MeuSorvete = {
            nomeSorvete: sorvete,
            vlPreco: preco
        }
        setLista([...lista, MeuSorvete]);
    }

    return (
        <div className="sorvete">

            <div className='faixa'>
                <Cabecalho />
            </div>

            <div className="Sorveteria-Compras">

                <div className="Img-Sorveteria">

                    <div className="divimg">

                        <img src="/assets/oio.png" alt="" />

                    </div>
                </div>


                <div className="divh1">
                    <h2>Sorveteria</h2>
                </div>



                <div className="Adicionar-Sorvete">
                    <div className="reto">

                        <h2>Novo Item</h2>
                        <input type="text" className="inputreal" value={sorvete} onChange={e => setSorvete(e.target.value)} />

                    </div>


                    <div className="naoreto">
                        <div className="border">R$</div>
                        <input type="text" value={preco} onChange={e => setPreco(Number(e.target.value))} />
                        <button onClick={Mostrar}> Adicionar </button>

                    </div>
                </div>

                <div className="Mostrar-Sorvete">

                    <div className="txt">
                        <h2 className="espaco">Lista de Compras</h2>

                        <h4>Total: R$ {resultado}</h4>
                    </div>


                    <div className="conta">
                        {lista.map(item =>
                            <div className="formats">
                                <p> {item.nomeSorvete} </p>
                                <p> R$ {item.vlPreco} </p>
                            </div>
                        )}
                    </div>

                </div>

            </div>
        </div>
    );
}