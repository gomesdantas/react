import './index.scss';

export default function Cabecalho () {
        return (

        <div className="cabecalho"> 
            <img className="logo" src='/assets/logo.png'></img>

            <p>Portifolio.me</p>

        </div>  
        )

}