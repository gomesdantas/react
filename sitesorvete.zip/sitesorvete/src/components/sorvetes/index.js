import './index.scss';

export default function Sorvetes(props) {

    return (
        <div className='sorvetes-card'>
            <h1>{props.item}</h1>
            <p>{props.preco}</p>
           
        </div>
    )
}