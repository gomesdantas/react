
import './index.scss';

import { Link } from 'react-router-dom';


export default function Pai() {



  return (
    <div className="Pai">

      <div className='container'>
        <div className='titulo'> <h1>DIA DOS PAIS</h1></div>

        <div className="container2">
          <div className='textos'>
            <h1>Figura</h1>
            <p>A figura paterna que não tive presente, foi representada de outras formas, não tive o pai que tanto sonhei ou invejei, mas tive pessoas que foram melhores que meu sonhos e que eu nunca imaginei.</p>

            <img src="" alt="" />
          </div>
<div className='image'>
 
 

 <div class="carrosel">
    <div class="slide">
    <img src="/assets/lu.jfif" alt=""  />
    <p className='esconde'>TE AMO</p>
    </div>
    <div class="slide">
    <img src="/assets/l.jfif" alt=""  />
    <p className='esconde '>CABEÇUDO</p>
    </div>
  
  </div>

</div>
         
        </div>

        

      </div>


      
    </div>
  );
}

