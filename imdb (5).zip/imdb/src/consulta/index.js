
import './index.scss';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import axios from 'axios';
import { useEffect } from 'react';

export default function Consulta() {

  const [filme, setFilme] = useState('');
  const [listaFilmes, setListaFilmes] = useState([]);
  const [proxima, setProxima] = useState(1);
 


  useEffect(() => {
    buscar();
  }, [proxima])




  async function buscar() {
    if (proxima < 1)
      setProxima(1);

    if (filme != '') {

      let url = "https://www.omdbapi.com?apikey=bc4c0d0c&s=" + filme + "&page=" + proxima;
      let response = await axios.get(url);
      setListaFilmes(response.data.Search);

    }
    

  }

  async function mais(){

    let ver=(proxima+1)

    let url = "https://www.omdbapi.com?apikey=bc4c0d0c&s=" + filme + "&page=" + ver;
      let response = await axios.get(url);
      setListaFilmes([...listaFilmes, ...response.data.Search]);
  }

  function Clique() {
    setProxima(proxima + 1);
  }


  return (
    <div className="pagina-consulta">

      <div className='faixa-aqui'>
        <img src="/assets/icon.png" alt="" />
        <p>Portifólio.me</p>
      </div>



      <div className='container'>
        <div className='c-faixa'>
          <p>IMDB</p>
        </div>
        <div className='centro'>


          <div className='infos'>

            <h5>Consulta de Filmes</h5>
            <div className="pesquisa">
              <label> Nome</label>
              <input type="text" value={filme} onChange={e => setFilme(e.target.value)} />

              <img className='lupa' src="/assets/lupa.png" alt="" onClick={buscar} />
            </div>



          </div>

          <div className='lista'>

            <table>
              <thead>
                <tr>
                  <th> Código</th>

                  <th>Título</th>

                  <th>Ano</th>
                </tr>
              </thead>
              <tbody>

                {
                  listaFilmes.map(item =>
                    <tr>
                      <td>  {item.imdbID}  <img src={item.Poster} alt="" /></td>
                      <td>{item.Title}</td>
                      <td>{item.Year}</td>
                    </tr>

                  )
                }
              </tbody>
            </table>


          </div>

          

        </div>
        <div className='botoes'>


            <button onClick={mais}> Ler mais</button>

            <button onClick={Clique}> 
              
              {listaFilmes.length > 0 && 
                <span>({proxima})</span>
              }

            Próximo 
            </button>


          </div>
      </div>


    </div>
  );
}

