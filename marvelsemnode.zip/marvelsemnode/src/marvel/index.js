import axios from 'axios';
import './index.scss';
import { Link } from 'react-router-dom';
import { useState } from 'react';

export default function Marvel() {


  const [herois, setHerois] = useState('');
  const [listaherois, setListaherois] = useState([]);
 

  async function procurar() {
  
    

    let url = "https://gateway.marvel.com/v1/public/characters?apikey=0848962e7d13d9b7e7d1292094706cc7&ts=1691895549&hash=b4aab47954c1759ca7a888f6104e404f&nameStartsWith=" + herois;
    let response = await axios.get(url);
    setListaherois([...response.data.data.results]);
    }
  

  return (
    <div className="marvel">

      <div className='faixa'>
        <img src="/assets/marvel.png" alt="" />

        <div className='menu'>
          <a>Home</a>
          <a>Personagens</a>
          <a>Quadrinhos</a>
          <a>Eventos</a>
          <a>Contato</a>
          <img src="/assets/m.png" alt="" />
        </div>

      </div>
      <div className='container'>
        <div className='texto'>
          <div className='title'><h1>Personagens </h1>
            <h2>da Marvel</h2></div>

          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elementum augue ut ligula malesuada blandit. Quisque tempor ex quis congue malesuada. Pellentesque est eros, aliquam non malesuada et, molestie ut purus.</p>

        </div>
        <div className='pesquisa'>

          <input type="text" value={herois
        } onChange={e => setHerois(e.target.value)  }placeholder='Nome do personagem' />
          <img src="/assets/union.png" alt="" onClick={procurar}  />
        </div>

        <div className='container2'>


<div className='filtro'>


      {
        listaherois.map(item =>
       
            <div className='conteudo'>
              <div className='personagem'>
           
              <img className="imagem" src={`${item.thumbnail.path}.${item.thumbnail.extension}`} />
              <h1>    {item.name}</h1>       
              <p className='descricao'>{item.description==="" || item.description === ""?
            "Não tem descrição no momento" :
            item.description  
            }</p>                   
      
            </div>
            </div>             
        

        )
      }

</div>

</div>
      </div>
    


    </div>
  );
}


