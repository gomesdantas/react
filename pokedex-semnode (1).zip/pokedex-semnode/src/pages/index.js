
import './index.scss';
import { useState } from 'react';
import axios from 'axios';

export default function Pokedex() {

  const [pokemons, setPokemons] = useState([]);
  const [proximo, setProximo] = useState(4);


  async function buscarPokemon() {

    let url = 'https://pokeapi.co/api/v2/pokemon/?offset=0&limit=8';

    let response = await axios.get(url);

    let listapoke = [];

    for (let item of response.data.results) {

      let pokemonresp = await axios.get(item.url);

      let imagem = pokemonresp.data.sprites.other['official-artwork'].front_default;

      let tipos = '';
      for (let t of pokemonresp.data.types) {

        tipos = tipos + t.type.name + ' ';

      }

      listapoke.push({


        nome: item.name,
        imagem: imagem,
        tipos: tipos

      })


    }

    setPokemons(listapoke);


  }


  async function mais(){

    let listapoke2 = [];

    let ver = (proximo + 4);

    let url2 = 'https://pokeapi.co/api/v2/pokemon/?offset=' + ver +'&limit=12&next=0';


    let response2 = await axios.get(url2);


    for (let item of response2.data.results) {

      let pokemonresp2 = await axios.get(item.url);

      

      let imagem = pokemonresp2.data.sprites.other['official-artwork'].front_default;

      let tipos = '';
      for (let t of pokemonresp2.data.types) {

        tipos = tipos + t.type.name + ' ';

      }

      listapoke2.push({


        nome: item.name,
        imagem: imagem,
        tipos: tipos

      })


    setPokemons([...pokemons, ...listapoke2]);
    }

  }

    return (
      <div className="pag-pokedex">

        <div className="cima">

          <img src="/assets/images/pika.png" alt="" />

          <button onClick={buscarPokemon}>  Encontrar pokémons  </button>



        </div>


        <div className="baixo">


          {pokemons.map(item =>

            <div className="pokecard">
              <img src={item.imagem} />
              <h1> {item.nome} </h1>
              <p> {item.tipos} </p>
            </div>
          )}


        </div>
        

            <div className="botaobaixo"> 

            <button onClick={mais} >  Buscar mais </button>


            </div>

      </div>
    )
  }


