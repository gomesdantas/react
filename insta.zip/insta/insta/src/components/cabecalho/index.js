import './index.scss';


export default function Cabecalho() {

    return(


        <div className="compcabecalho">


        <div className="marca">

            <img src="assets/images/logo.png" alt="" />
            <p> Portifólio.me </p>

        </div>

        <div className="botoes">

            <div> 
                <img src="assets/images/home.png" alt="" /> 
                <a href=""> Página Inicial </a> 
            </div>

            <div> 
                <img src="/assets/images/pesquisa.png" alt="" /> 
                <a href=""> Pesquisa </a> 
            </div>

            <div> 
                <img src="/assets/images/reels.png" alt="" /> 
                <a href=""> Reels </a> 
            </div>

            <div> 
                <img src="/assets/images/mensagens.png" alt="" /> 
                <a href=""> Mensagens </a> 
            </div>

            <div> 
                <img src="/assets/images/notificacoes.png" alt="" /> 
                <a href=""> Notificações </a> 
            </div>

            <div> 
                <img src="/assets/images/criar.png" alt="" /> 
                <a href=""> Criar </a> 
            </div>

        </div>

        </div>

    )

}