
import './App.scss';

import Cabecalho from '../../components/cabecalho';
import { useState } from 'react';




function App() {



  const [usuario, setUsuario] = useState('');
  const [tempo, setTempo] = useState('');
  const [avatar, setAvatar] = useState('');
  const [descricao, setDescricao] = useState('');
  const [post, setPost] = useState('');
  const [curtidas, setCurtidas] = useState('');
  const [postfinal, setPostfinal] = useState([]);


  const posttotal = () => {
    let infoPost = {


      usuario: usuario,
      tempo: tempo,
      avatar: avatar,
      descricao: descricao,
      post: post,
      curtidas: curtidas

    }

    setPostfinal([...postfinal, infoPost]);

  }

  return (
    <div className="paginainsta">

      <div className='cabecalho'>

        <Cabecalho />

      </div>

      <div className="conteudo">

        <div className='stories'>


          <div>

            <img src="/assets/images/pessoa1.png" alt="" />

          </div>

          <div>

            <img src="/assets/images/pessoa2.png" alt="" />

          </div>

          <div className='pessoa3'>

            <img src="/assets/images/pessoa3.png" alt="" />

          </div>

          <div>

            <img src="/assets/images/pessoa4.png" alt="" />

          </div>

          <div>

            <img src="/assets/images/pessoa5.png" alt="" />

          </div>

          <div>

            <img src="/assets/images/pessoa6.png" alt="" />

          </div>

          <div>

            <img src="/assets/images/pessoa7.png" alt="" />

          </div>

          <div>

            <img src="/assets/images/pessoa8.png" alt="" />

          </div>

        </div>



        <div className="inputz">


          <div className="specialinputz">

            <div>

              Usuário: <input type="text" value={usuario} onChange={e => setUsuario(e.target.value)} />

            </div>

            <div>

              Tempo: <input type="text" value={tempo} onChange={e => setTempo(e.target.value)} />

            </div>

          </div>

          <div>


            <div className="avatarbox">

              Avatar: <input type="text" value={avatar} onChange={e => setAvatar(e.target.value)} />

            </div>

            <div className='descricaobox'>

              Descrição: <input type="text" value={descricao} onChange={e => setDescricao(e.target.value)} />

            </div>

            <div className="specialinputz">

              <div>

                Post: <input type="text" value={post} onChange={e => setPost(e.target.value)} />

              </div>

              <div>

                Curtidas: <input type="text" value={curtidas} onChange={e => setCurtidas(Number(e.target.value))} />

              </div>

            </div>

          </div>

          <button onClick={posttotal}> Postar </button>

        </div>




        <div className='post'>


          {postfinal.map(item =>
            <div className="formats">

              <div className="cabpost">

                <img src={item.avatar} alt="" />

                <h4> {item.usuario}</h4>

                <div className="clarinho">
                  <div> . </div>

                  <h4> {item.tempo} </h4>
                </div>


              </div>

              <img src={item.post} alt="" />

              <div className='div2'>

                <img src="/assets/images/notificacoes.png" alt="" />

                <img src="/assets/images/mensagens.png" alt="" />

              </div>

              <div className='div3'>

                <h4> {item.curtidas} curtidas </h4>

              </div>

              <div className="divfinal">


                <h4> {item.usuario} </h4>
                <p> {item.descricao} </p>

              </div>

            </div>
          )}


        </div>





      </div>

    </div>
  );
}

export default App;
